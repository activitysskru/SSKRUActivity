<?php
$db_hostname="localhost";
$db_user="itsisake_csit";
$db_password="csitsskru_123";
$db_name="itsisake_csit";
?>